The two layer board design contains no drill files because there are no vias
and there are no holes in the PCB.

Because I only need the silkscreen on the bottom layer, I've submitted only
the bottom layer silksreen.

The files are using the protel file extensions, but here's the meaning of each
file. The units inside files are in mm.

bottom copper layer       | fault-injector-3-B_Cu.gbl
bottom solder mask layer  | fault-injector-3-B_Mask.gbs
bottom silk screen        | fault-injector-3-B_SilkS.gbo
board outline             | fault-injector-3-Edge_Cuts.gm1
top copper layer          | fault-injector-3-F_Cu.gtl
top solder mask           | fault-injector-3-F_Mask.gts